- 修复不能清空群聊天记录的bug
- 修复3D Touch造成的bug




