//
//  JailBreakHelper.mm
//  JailBreakHelper
//
//  Created by 王文臻 on 2017/2/5.
//  Copyright (c) 2017年 susnm. All rights reserved.
//

#pragma mark- 防越狱检测
CHOptimizedMethod0(self, BOOL, JailBreakHelper, IsJailBreak) {
  return NO;
}
